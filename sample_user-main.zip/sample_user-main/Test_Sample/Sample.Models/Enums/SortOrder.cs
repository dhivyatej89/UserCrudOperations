﻿namespace Sample.Models.Enums
{
    public enum SortOrder
    {
        Asc = 0,
        Desc = 1,
    }
}
